﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace WindowsFormsApp9
{
    public partial class login : Form
    {
        

        public login()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            string kullaniciadi = tbadi.Text;
            string sifre = tbsifre.Text;

            Anasayfa form2 = new Anasayfa();

            if (GirisKontrolu(kullaniciadi, sifre, "admin"))
            {
                MessageBox.Show("Admin girişi yapıldı!");
                this.Hide();
                form2.Show();

                

                tbadi.Text = "";
                tbsifre.Text = "";
            }
            else if (GirisKontrolu(kullaniciadi, sifre, "personel"))
            {
                MessageBox.Show("Personel girişi yapıldı!");
                this.Hide();
                Personel per = new Personel();
                per.Show();


                tbadi.Text = "";
                tbsifre.Text = "";
            }
            else
            {
                MessageBox.Show("Yanlış kullanıcı adı veya şifre!");
                tbadi.Text = "";
                tbsifre.Text = "";
            }


        }
        private bool GirisKontrolu(string kullaniciAdi, string sifre, string tabloAdi)
        {
            string connectionString = "Server=localhost;Database=otelsistem;User Id=otelsistem;Password=1230789Asd!";
            MySqlConnection connection = new MySqlConnection(connectionString);

            try
            {
                connection.Open();

                string query = $"SELECT COUNT(*) FROM {tabloAdi} WHERE KullaniciAdi = @kullaniciAdi AND Sifre = @sifre";
                MySqlCommand command = new MySqlCommand(query, connection);
                command.Parameters.AddWithValue("@kullaniciAdi", kullaniciAdi);
                command.Parameters.AddWithValue("@sifre", sifre);

                int kullaniciSayisi = Convert.ToInt32(command.ExecuteScalar());

                return kullaniciSayisi > 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
                return false;
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }

        private void guna2ControlBox1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void guna2PictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void guna2TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void guna2TextBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
