﻿
namespace WindowsFormsApp9
{
    partial class Odalar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.guna2GroupBox1 = new Guna.UI2.WinForms.Guna2GroupBox();
            this.guna2Button17 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button16 = new Guna.UI2.WinForms.Guna2Button();
            this.oda515 = new Guna.UI2.WinForms.Guna2Button();
            this.oda514 = new Guna.UI2.WinForms.Guna2Button();
            this.oda513 = new Guna.UI2.WinForms.Guna2Button();
            this.oda412 = new Guna.UI2.WinForms.Guna2Button();
            this.oda411 = new Guna.UI2.WinForms.Guna2Button();
            this.oda410 = new Guna.UI2.WinForms.Guna2Button();
            this.oda309 = new Guna.UI2.WinForms.Guna2Button();
            this.oda308 = new Guna.UI2.WinForms.Guna2Button();
            this.oda307 = new Guna.UI2.WinForms.Guna2Button();
            this.oda206 = new Guna.UI2.WinForms.Guna2Button();
            this.oda205 = new Guna.UI2.WinForms.Guna2Button();
            this.oda204 = new Guna.UI2.WinForms.Guna2Button();
            this.oda103 = new Guna.UI2.WinForms.Guna2Button();
            this.oda102 = new Guna.UI2.WinForms.Guna2Button();
            this.oda101 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button18 = new Guna.UI2.WinForms.Guna2Button();
            this.lbekran = new System.Windows.Forms.ListBox();
            this.guna2GroupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // guna2GroupBox1
            // 
            this.guna2GroupBox1.Controls.Add(this.guna2Button17);
            this.guna2GroupBox1.Controls.Add(this.guna2Button16);
            this.guna2GroupBox1.Controls.Add(this.oda515);
            this.guna2GroupBox1.Controls.Add(this.oda514);
            this.guna2GroupBox1.Controls.Add(this.oda513);
            this.guna2GroupBox1.Controls.Add(this.oda412);
            this.guna2GroupBox1.Controls.Add(this.oda411);
            this.guna2GroupBox1.Controls.Add(this.oda410);
            this.guna2GroupBox1.Controls.Add(this.oda309);
            this.guna2GroupBox1.Controls.Add(this.oda308);
            this.guna2GroupBox1.Controls.Add(this.oda307);
            this.guna2GroupBox1.Controls.Add(this.oda206);
            this.guna2GroupBox1.Controls.Add(this.oda205);
            this.guna2GroupBox1.Controls.Add(this.oda204);
            this.guna2GroupBox1.Controls.Add(this.oda103);
            this.guna2GroupBox1.Controls.Add(this.oda102);
            this.guna2GroupBox1.Controls.Add(this.oda101);
            this.guna2GroupBox1.FillColor = System.Drawing.SystemColors.ActiveCaption;
            this.guna2GroupBox1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2GroupBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2GroupBox1.Location = new System.Drawing.Point(12, 12);
            this.guna2GroupBox1.Name = "guna2GroupBox1";
            this.guna2GroupBox1.Size = new System.Drawing.Size(630, 303);
            this.guna2GroupBox1.TabIndex = 18;
            this.guna2GroupBox1.Text = "Odalar";
            this.guna2GroupBox1.Click += new System.EventHandler(this.guna2GroupBox1_Click);
            // 
            // guna2Button17
            // 
            this.guna2Button17.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button17.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button17.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button17.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button17.FillColor = System.Drawing.Color.Red;
            this.guna2Button17.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button17.ForeColor = System.Drawing.Color.White;
            this.guna2Button17.Location = new System.Drawing.Point(436, 221);
            this.guna2Button17.Name = "guna2Button17";
            this.guna2Button17.Size = new System.Drawing.Size(86, 60);
            this.guna2Button17.TabIndex = 16;
            this.guna2Button17.Text = "Dolu";
            this.guna2Button17.Click += new System.EventHandler(this.guna2Button17_Click);
            // 
            // guna2Button16
            // 
            this.guna2Button16.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button16.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button16.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button16.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button16.FillColor = System.Drawing.Color.DarkGreen;
            this.guna2Button16.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button16.ForeColor = System.Drawing.Color.White;
            this.guna2Button16.Location = new System.Drawing.Point(327, 221);
            this.guna2Button16.Name = "guna2Button16";
            this.guna2Button16.Size = new System.Drawing.Size(86, 60);
            this.guna2Button16.TabIndex = 15;
            this.guna2Button16.Text = "Boş";
            this.guna2Button16.Click += new System.EventHandler(this.guna2Button16_Click);
            // 
            // oda515
            // 
            this.oda515.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.oda515.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.oda515.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.oda515.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.oda515.FillColor = System.Drawing.Color.DarkGreen;
            this.oda515.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.oda515.ForeColor = System.Drawing.Color.White;
            this.oda515.Location = new System.Drawing.Point(225, 221);
            this.oda515.Name = "oda515";
            this.oda515.Size = new System.Drawing.Size(86, 60);
            this.oda515.TabIndex = 14;
            this.oda515.Text = "515";
            // 
            // oda514
            // 
            this.oda514.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.oda514.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.oda514.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.oda514.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.oda514.FillColor = System.Drawing.Color.DarkGreen;
            this.oda514.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.oda514.ForeColor = System.Drawing.Color.White;
            this.oda514.Location = new System.Drawing.Point(121, 221);
            this.oda514.Name = "oda514";
            this.oda514.Size = new System.Drawing.Size(86, 60);
            this.oda514.TabIndex = 13;
            this.oda514.Text = "514";
            // 
            // oda513
            // 
            this.oda513.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.oda513.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.oda513.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.oda513.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.oda513.FillColor = System.Drawing.Color.DarkGreen;
            this.oda513.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.oda513.ForeColor = System.Drawing.Color.White;
            this.oda513.Location = new System.Drawing.Point(16, 221);
            this.oda513.Name = "oda513";
            this.oda513.Size = new System.Drawing.Size(86, 60);
            this.oda513.TabIndex = 12;
            this.oda513.Text = "513";
            // 
            // oda412
            // 
            this.oda412.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.oda412.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.oda412.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.oda412.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.oda412.FillColor = System.Drawing.Color.DarkGreen;
            this.oda412.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.oda412.ForeColor = System.Drawing.Color.White;
            this.oda412.Location = new System.Drawing.Point(536, 136);
            this.oda412.Name = "oda412";
            this.oda412.Size = new System.Drawing.Size(86, 60);
            this.oda412.TabIndex = 11;
            this.oda412.Text = "412";
            // 
            // oda411
            // 
            this.oda411.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.oda411.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.oda411.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.oda411.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.oda411.FillColor = System.Drawing.Color.DarkGreen;
            this.oda411.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.oda411.ForeColor = System.Drawing.Color.White;
            this.oda411.Location = new System.Drawing.Point(432, 136);
            this.oda411.Name = "oda411";
            this.oda411.Size = new System.Drawing.Size(86, 60);
            this.oda411.TabIndex = 10;
            this.oda411.Text = "411";
            // 
            // oda410
            // 
            this.oda410.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.oda410.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.oda410.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.oda410.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.oda410.FillColor = System.Drawing.Color.DarkGreen;
            this.oda410.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.oda410.ForeColor = System.Drawing.Color.White;
            this.oda410.Location = new System.Drawing.Point(327, 136);
            this.oda410.Name = "oda410";
            this.oda410.Size = new System.Drawing.Size(86, 60);
            this.oda410.TabIndex = 9;
            this.oda410.Text = "410";
            // 
            // oda309
            // 
            this.oda309.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.oda309.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.oda309.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.oda309.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.oda309.FillColor = System.Drawing.Color.DarkGreen;
            this.oda309.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.oda309.ForeColor = System.Drawing.Color.White;
            this.oda309.Location = new System.Drawing.Point(225, 136);
            this.oda309.Name = "oda309";
            this.oda309.Size = new System.Drawing.Size(86, 60);
            this.oda309.TabIndex = 8;
            this.oda309.Text = "309";
            // 
            // oda308
            // 
            this.oda308.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.oda308.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.oda308.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.oda308.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.oda308.FillColor = System.Drawing.Color.DarkGreen;
            this.oda308.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.oda308.ForeColor = System.Drawing.Color.White;
            this.oda308.Location = new System.Drawing.Point(121, 136);
            this.oda308.Name = "oda308";
            this.oda308.Size = new System.Drawing.Size(86, 60);
            this.oda308.TabIndex = 7;
            this.oda308.Text = "308";
            // 
            // oda307
            // 
            this.oda307.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.oda307.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.oda307.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.oda307.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.oda307.FillColor = System.Drawing.Color.DarkGreen;
            this.oda307.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.oda307.ForeColor = System.Drawing.Color.White;
            this.oda307.Location = new System.Drawing.Point(16, 136);
            this.oda307.Name = "oda307";
            this.oda307.Size = new System.Drawing.Size(86, 60);
            this.oda307.TabIndex = 6;
            this.oda307.Text = "307";
            // 
            // oda206
            // 
            this.oda206.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.oda206.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.oda206.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.oda206.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.oda206.FillColor = System.Drawing.Color.DarkGreen;
            this.oda206.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.oda206.ForeColor = System.Drawing.Color.White;
            this.oda206.Location = new System.Drawing.Point(536, 57);
            this.oda206.Name = "oda206";
            this.oda206.Size = new System.Drawing.Size(86, 60);
            this.oda206.TabIndex = 5;
            this.oda206.Text = "206";
            // 
            // oda205
            // 
            this.oda205.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.oda205.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.oda205.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.oda205.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.oda205.FillColor = System.Drawing.Color.DarkGreen;
            this.oda205.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.oda205.ForeColor = System.Drawing.Color.White;
            this.oda205.Location = new System.Drawing.Point(432, 57);
            this.oda205.Name = "oda205";
            this.oda205.Size = new System.Drawing.Size(86, 60);
            this.oda205.TabIndex = 4;
            this.oda205.Text = "205";
            // 
            // oda204
            // 
            this.oda204.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.oda204.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.oda204.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.oda204.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.oda204.FillColor = System.Drawing.Color.DarkGreen;
            this.oda204.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.oda204.ForeColor = System.Drawing.Color.White;
            this.oda204.Location = new System.Drawing.Point(327, 57);
            this.oda204.Name = "oda204";
            this.oda204.Size = new System.Drawing.Size(86, 60);
            this.oda204.TabIndex = 3;
            this.oda204.Text = "204";
            // 
            // oda103
            // 
            this.oda103.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.oda103.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.oda103.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.oda103.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.oda103.FillColor = System.Drawing.Color.DarkGreen;
            this.oda103.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.oda103.ForeColor = System.Drawing.Color.White;
            this.oda103.Location = new System.Drawing.Point(225, 57);
            this.oda103.Name = "oda103";
            this.oda103.Size = new System.Drawing.Size(86, 60);
            this.oda103.TabIndex = 2;
            this.oda103.Text = "103";
            // 
            // oda102
            // 
            this.oda102.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.oda102.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.oda102.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.oda102.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.oda102.FillColor = System.Drawing.Color.DarkGreen;
            this.oda102.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.oda102.ForeColor = System.Drawing.Color.White;
            this.oda102.Location = new System.Drawing.Point(121, 57);
            this.oda102.Name = "oda102";
            this.oda102.Size = new System.Drawing.Size(86, 60);
            this.oda102.TabIndex = 1;
            this.oda102.Text = "102";
            // 
            // oda101
            // 
            this.oda101.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.oda101.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.oda101.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.oda101.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.oda101.FillColor = System.Drawing.Color.DarkGreen;
            this.oda101.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.oda101.ForeColor = System.Drawing.Color.White;
            this.oda101.Location = new System.Drawing.Point(16, 57);
            this.oda101.Name = "oda101";
            this.oda101.Size = new System.Drawing.Size(86, 60);
            this.oda101.TabIndex = 0;
            this.oda101.Text = "101";
            this.oda101.Click += new System.EventHandler(this.guna2Button1_Click);
            // 
            // guna2Button18
            // 
            this.guna2Button18.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button18.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button18.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button18.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button18.FillColor = System.Drawing.Color.DarkSlateGray;
            this.guna2Button18.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button18.ForeColor = System.Drawing.Color.White;
            this.guna2Button18.Location = new System.Drawing.Point(648, 487);
            this.guna2Button18.Name = "guna2Button18";
            this.guna2Button18.Size = new System.Drawing.Size(122, 45);
            this.guna2Button18.TabIndex = 19;
            this.guna2Button18.Text = "Geri";
            this.guna2Button18.Click += new System.EventHandler(this.guna2Button18_Click);
            // 
            // lbekran
            // 
            this.lbekran.FormattingEnabled = true;
            this.lbekran.ItemHeight = 16;
            this.lbekran.Location = new System.Drawing.Point(12, 321);
            this.lbekran.Name = "lbekran";
            this.lbekran.Size = new System.Drawing.Size(622, 212);
            this.lbekran.TabIndex = 20;
            // 
            // Odalar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(781, 544);
            this.Controls.Add(this.lbekran);
            this.Controls.Add(this.guna2Button18);
            this.Controls.Add(this.guna2GroupBox1);
            this.Name = "Odalar";
            this.Text = "Odalar";
            this.Load += new System.EventHandler(this.Odalar_Load);
            this.guna2GroupBox1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2GroupBox guna2GroupBox1;
        private Guna.UI2.WinForms.Guna2Button guna2Button17;
        private Guna.UI2.WinForms.Guna2Button guna2Button16;
        private Guna.UI2.WinForms.Guna2Button oda515;
        private Guna.UI2.WinForms.Guna2Button oda514;
        private Guna.UI2.WinForms.Guna2Button oda513;
        private Guna.UI2.WinForms.Guna2Button oda412;
        private Guna.UI2.WinForms.Guna2Button oda411;
        private Guna.UI2.WinForms.Guna2Button oda410;
        private Guna.UI2.WinForms.Guna2Button oda309;
        private Guna.UI2.WinForms.Guna2Button oda308;
        private Guna.UI2.WinForms.Guna2Button oda307;
        private Guna.UI2.WinForms.Guna2Button oda206;
        private Guna.UI2.WinForms.Guna2Button oda205;
        private Guna.UI2.WinForms.Guna2Button oda204;
        private Guna.UI2.WinForms.Guna2Button oda103;
        private Guna.UI2.WinForms.Guna2Button oda102;
        private Guna.UI2.WinForms.Guna2Button oda101;
        private Guna.UI2.WinForms.Guna2Button guna2Button18;
        private System.Windows.Forms.ListBox lbekran;
    }
}