﻿
namespace WindowsFormsApp9
{
    partial class YeniMusteri
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tbad = new Guna.UI2.WinForms.Guna2TextBox();
            this.tbsoyad = new Guna.UI2.WinForms.Guna2TextBox();
            this.tbtckimlik = new Guna.UI2.WinForms.Guna2TextBox();
            this.tbtelno = new Guna.UI2.WinForms.Guna2TextBox();
            this.tbodano = new Guna.UI2.WinForms.Guna2TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.dtpgiristarihi = new Guna.UI2.WinForms.Guna2DateTimePicker();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.dtpcıkıstarihi = new Guna.UI2.WinForms.Guna2DateTimePicker();
            this.btnkaydet = new Guna.UI2.WinForms.Guna2Button();
            this.gbodalar = new Guna.UI2.WinForms.Guna2GroupBox();
            this.guna2Button17 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button16 = new Guna.UI2.WinForms.Guna2Button();
            this.btn515 = new Guna.UI2.WinForms.Guna2Button();
            this.btn514 = new Guna.UI2.WinForms.Guna2Button();
            this.btn513 = new Guna.UI2.WinForms.Guna2Button();
            this.btn412 = new Guna.UI2.WinForms.Guna2Button();
            this.btn411 = new Guna.UI2.WinForms.Guna2Button();
            this.btn410 = new Guna.UI2.WinForms.Guna2Button();
            this.btn309 = new Guna.UI2.WinForms.Guna2Button();
            this.btn308 = new Guna.UI2.WinForms.Guna2Button();
            this.btn307 = new Guna.UI2.WinForms.Guna2Button();
            this.btn206 = new Guna.UI2.WinForms.Guna2Button();
            this.btn205 = new Guna.UI2.WinForms.Guna2Button();
            this.btn204 = new Guna.UI2.WinForms.Guna2Button();
            this.btn103 = new Guna.UI2.WinForms.Guna2Button();
            this.btn102 = new Guna.UI2.WinForms.Guna2Button();
            this.btn101 = new Guna.UI2.WinForms.Guna2Button();
            this.label9 = new System.Windows.Forms.Label();
            this.tbucret = new Guna.UI2.WinForms.Guna2TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.guna2GroupBox2 = new Guna.UI2.WinForms.Guna2GroupBox();
            this.dtpdogum = new Guna.UI2.WinForms.Guna2DateTimePicker();
            this.guna2Button18 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2GroupBox3 = new Guna.UI2.WinForms.Guna2GroupBox();
            this.guna2Button20 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button19 = new Guna.UI2.WinForms.Guna2Button();
            this.label11 = new System.Windows.Forms.Label();
            this.tbmusteriid = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2BorderlessForm1 = new Guna.UI2.WinForms.Guna2BorderlessForm(this.components);
            this.guna2ControlBox1 = new Guna.UI2.WinForms.Guna2ControlBox();
            this.label12 = new System.Windows.Forms.Label();
            this.lbbosoda = new System.Windows.Forms.Label();
            this.lbdoluoda = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.gbodalar.SuspendLayout();
            this.guna2GroupBox2.SuspendLayout();
            this.guna2GroupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // tbad
            // 
            this.tbad.BorderRadius = 13;
            this.tbad.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tbad.DefaultText = "";
            this.tbad.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.tbad.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.tbad.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbad.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbad.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbad.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.tbad.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbad.Location = new System.Drawing.Point(126, 77);
            this.tbad.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tbad.Name = "tbad";
            this.tbad.PasswordChar = '\0';
            this.tbad.PlaceholderText = "";
            this.tbad.SelectedText = "";
            this.tbad.Size = new System.Drawing.Size(145, 26);
            this.tbad.TabIndex = 0;
            // 
            // tbsoyad
            // 
            this.tbsoyad.BorderRadius = 13;
            this.tbsoyad.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tbsoyad.DefaultText = "";
            this.tbsoyad.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.tbsoyad.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.tbsoyad.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbsoyad.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbsoyad.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbsoyad.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.tbsoyad.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbsoyad.Location = new System.Drawing.Point(126, 127);
            this.tbsoyad.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tbsoyad.Name = "tbsoyad";
            this.tbsoyad.PasswordChar = '\0';
            this.tbsoyad.PlaceholderText = "";
            this.tbsoyad.SelectedText = "";
            this.tbsoyad.Size = new System.Drawing.Size(145, 26);
            this.tbsoyad.TabIndex = 1;
            this.tbsoyad.TextChanged += new System.EventHandler(this.guna2TextBox2_TextChanged);
            // 
            // tbtckimlik
            // 
            this.tbtckimlik.BorderRadius = 13;
            this.tbtckimlik.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tbtckimlik.DefaultText = "";
            this.tbtckimlik.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.tbtckimlik.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.tbtckimlik.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbtckimlik.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbtckimlik.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbtckimlik.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.tbtckimlik.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbtckimlik.Location = new System.Drawing.Point(126, 227);
            this.tbtckimlik.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tbtckimlik.Name = "tbtckimlik";
            this.tbtckimlik.PasswordChar = '\0';
            this.tbtckimlik.PlaceholderText = "";
            this.tbtckimlik.SelectedText = "";
            this.tbtckimlik.Size = new System.Drawing.Size(145, 26);
            this.tbtckimlik.TabIndex = 3;
            // 
            // tbtelno
            // 
            this.tbtelno.BorderRadius = 13;
            this.tbtelno.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tbtelno.DefaultText = "";
            this.tbtelno.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.tbtelno.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.tbtelno.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbtelno.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbtelno.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbtelno.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.tbtelno.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbtelno.Location = new System.Drawing.Point(126, 277);
            this.tbtelno.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tbtelno.Name = "tbtelno";
            this.tbtelno.PasswordChar = '\0';
            this.tbtelno.PlaceholderText = "";
            this.tbtelno.SelectedText = "";
            this.tbtelno.Size = new System.Drawing.Size(145, 26);
            this.tbtelno.TabIndex = 4;
            this.tbtelno.TextChanged += new System.EventHandler(this.guna2TextBox5_TextChanged);
            // 
            // tbodano
            // 
            this.tbodano.BorderRadius = 13;
            this.tbodano.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tbodano.DefaultText = "";
            this.tbodano.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.tbodano.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.tbodano.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbodano.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbodano.Enabled = false;
            this.tbodano.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbodano.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.tbodano.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbodano.Location = new System.Drawing.Point(126, 327);
            this.tbodano.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tbodano.Name = "tbodano";
            this.tbodano.PasswordChar = '\0';
            this.tbodano.PlaceholderText = "";
            this.tbodano.SelectedText = "";
            this.tbodano.Size = new System.Drawing.Size(145, 26);
            this.tbodano.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(95, 77);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(28, 20);
            this.label1.TabIndex = 6;
            this.label1.Text = "Ad";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(72, 127);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 20);
            this.label2.TabIndex = 7;
            this.label2.Text = "Soyad";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(27, 177);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(98, 20);
            this.label3.TabIndex = 8;
            this.label3.Text = "Doğum Tarihi";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(27, 227);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(98, 20);
            this.label4.TabIndex = 9;
            this.label4.Text = "T.C Kimlik No";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(28, 277);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(82, 20);
            this.label5.TabIndex = 10;
            this.label5.Text = "Telefon No";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(21, 327);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(104, 20);
            this.label6.TabIndex = 11;
            this.label6.Text = "Oda Numarası";
            // 
            // dtpgiristarihi
            // 
            this.dtpgiristarihi.Animated = true;
            this.dtpgiristarihi.BackColor = System.Drawing.Color.Transparent;
            this.dtpgiristarihi.Checked = true;
            this.dtpgiristarihi.FillColor = System.Drawing.Color.White;
            this.dtpgiristarihi.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.dtpgiristarihi.Format = System.Windows.Forms.DateTimePickerFormat.Long;
            this.dtpgiristarihi.Location = new System.Drawing.Point(126, 414);
            this.dtpgiristarihi.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.dtpgiristarihi.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.dtpgiristarihi.Name = "dtpgiristarihi";
            this.dtpgiristarihi.Size = new System.Drawing.Size(200, 31);
            this.dtpgiristarihi.TabIndex = 12;
            this.dtpgiristarihi.Value = new System.DateTime(2024, 1, 12, 22, 26, 0, 771);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(21, 414);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(77, 20);
            this.label7.TabIndex = 13;
            this.label7.Text = "Giriş Tarihi";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(21, 470);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(78, 20);
            this.label8.TabIndex = 14;
            this.label8.Text = "Çıkış Tarihi";
            // 
            // dtpcıkıstarihi
            // 
            this.dtpcıkıstarihi.Checked = true;
            this.dtpcıkıstarihi.FillColor = System.Drawing.Color.White;
            this.dtpcıkıstarihi.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.dtpcıkıstarihi.Format = System.Windows.Forms.DateTimePickerFormat.Long;
            this.dtpcıkıstarihi.Location = new System.Drawing.Point(126, 470);
            this.dtpcıkıstarihi.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.dtpcıkıstarihi.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.dtpcıkıstarihi.Name = "dtpcıkıstarihi";
            this.dtpcıkıstarihi.Size = new System.Drawing.Size(200, 31);
            this.dtpcıkıstarihi.TabIndex = 15;
            this.dtpcıkıstarihi.Value = new System.DateTime(2024, 1, 12, 22, 26, 0, 771);
            this.dtpcıkıstarihi.ValueChanged += new System.EventHandler(this.guna2DateTimePicker2_ValueChanged);
            // 
            // btnkaydet
            // 
            this.btnkaydet.Animated = true;
            this.btnkaydet.AnimatedGIF = true;
            this.btnkaydet.BorderRadius = 15;
            this.btnkaydet.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnkaydet.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnkaydet.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnkaydet.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnkaydet.FillColor = System.Drawing.Color.DimGray;
            this.btnkaydet.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnkaydet.ForeColor = System.Drawing.Color.White;
            this.btnkaydet.Location = new System.Drawing.Point(126, 518);
            this.btnkaydet.Name = "btnkaydet";
            this.btnkaydet.Size = new System.Drawing.Size(200, 45);
            this.btnkaydet.TabIndex = 16;
            this.btnkaydet.Text = "Kaydet";
            this.btnkaydet.Click += new System.EventHandler(this.btnkaydet_Click);
            // 
            // gbodalar
            // 
            this.gbodalar.Controls.Add(this.lbdoluoda);
            this.gbodalar.Controls.Add(this.label14);
            this.gbodalar.Controls.Add(this.lbbosoda);
            this.gbodalar.Controls.Add(this.label12);
            this.gbodalar.Controls.Add(this.guna2Button17);
            this.gbodalar.Controls.Add(this.guna2Button16);
            this.gbodalar.Controls.Add(this.btn515);
            this.gbodalar.Controls.Add(this.btn514);
            this.gbodalar.Controls.Add(this.btn513);
            this.gbodalar.Controls.Add(this.btn412);
            this.gbodalar.Controls.Add(this.btn411);
            this.gbodalar.Controls.Add(this.btn410);
            this.gbodalar.Controls.Add(this.btn309);
            this.gbodalar.Controls.Add(this.btn308);
            this.gbodalar.Controls.Add(this.btn307);
            this.gbodalar.Controls.Add(this.btn206);
            this.gbodalar.Controls.Add(this.btn205);
            this.gbodalar.Controls.Add(this.btn204);
            this.gbodalar.Controls.Add(this.btn103);
            this.gbodalar.Controls.Add(this.btn102);
            this.gbodalar.Controls.Add(this.btn101);
            this.gbodalar.FillColor = System.Drawing.SystemColors.ActiveCaption;
            this.gbodalar.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gbodalar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.gbodalar.Location = new System.Drawing.Point(760, 54);
            this.gbodalar.Name = "gbodalar";
            this.gbodalar.Size = new System.Drawing.Size(333, 572);
            this.gbodalar.TabIndex = 17;
            this.gbodalar.Text = "Odalar";
            // 
            // guna2Button17
            // 
            this.guna2Button17.Animated = true;
            this.guna2Button17.BorderRadius = 15;
            this.guna2Button17.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button17.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button17.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button17.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button17.FillColor = System.Drawing.Color.Red;
            this.guna2Button17.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button17.ForeColor = System.Drawing.Color.White;
            this.guna2Button17.Location = new System.Drawing.Point(168, 403);
            this.guna2Button17.Name = "guna2Button17";
            this.guna2Button17.Size = new System.Drawing.Size(86, 60);
            this.guna2Button17.TabIndex = 16;
            this.guna2Button17.Text = "Dolu";
            this.guna2Button17.Click += new System.EventHandler(this.guna2Button17_Click);
            // 
            // guna2Button16
            // 
            this.guna2Button16.Animated = true;
            this.guna2Button16.BorderRadius = 15;
            this.guna2Button16.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button16.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button16.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button16.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button16.FillColor = System.Drawing.Color.DarkGreen;
            this.guna2Button16.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button16.ForeColor = System.Drawing.Color.White;
            this.guna2Button16.Location = new System.Drawing.Point(59, 403);
            this.guna2Button16.Name = "guna2Button16";
            this.guna2Button16.Size = new System.Drawing.Size(86, 60);
            this.guna2Button16.TabIndex = 15;
            this.guna2Button16.Text = "Boş";
            this.guna2Button16.Click += new System.EventHandler(this.guna2Button16_Click);
            // 
            // btn515
            // 
            this.btn515.Animated = true;
            this.btn515.BorderRadius = 15;
            this.btn515.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn515.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn515.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn515.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn515.FillColor = System.Drawing.Color.DarkGreen;
            this.btn515.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btn515.ForeColor = System.Drawing.Color.White;
            this.btn515.Location = new System.Drawing.Point(225, 337);
            this.btn515.Name = "btn515";
            this.btn515.Size = new System.Drawing.Size(86, 60);
            this.btn515.TabIndex = 14;
            this.btn515.Text = "515";
            this.btn515.Click += new System.EventHandler(this.guna2Button15_Click);
            // 
            // btn514
            // 
            this.btn514.Animated = true;
            this.btn514.BorderRadius = 15;
            this.btn514.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn514.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn514.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn514.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn514.FillColor = System.Drawing.Color.DarkGreen;
            this.btn514.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btn514.ForeColor = System.Drawing.Color.White;
            this.btn514.Location = new System.Drawing.Point(121, 337);
            this.btn514.Name = "btn514";
            this.btn514.Size = new System.Drawing.Size(86, 60);
            this.btn514.TabIndex = 13;
            this.btn514.Text = "514";
            this.btn514.Click += new System.EventHandler(this.guna2Button14_Click);
            // 
            // btn513
            // 
            this.btn513.Animated = true;
            this.btn513.BorderRadius = 15;
            this.btn513.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn513.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn513.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn513.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn513.FillColor = System.Drawing.Color.DarkGreen;
            this.btn513.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btn513.ForeColor = System.Drawing.Color.White;
            this.btn513.Location = new System.Drawing.Point(16, 337);
            this.btn513.Name = "btn513";
            this.btn513.Size = new System.Drawing.Size(86, 60);
            this.btn513.TabIndex = 12;
            this.btn513.Text = "513";
            this.btn513.Click += new System.EventHandler(this.guna2Button13_Click);
            // 
            // btn412
            // 
            this.btn412.Animated = true;
            this.btn412.BorderRadius = 15;
            this.btn412.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn412.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn412.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn412.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn412.FillColor = System.Drawing.Color.DarkGreen;
            this.btn412.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btn412.ForeColor = System.Drawing.Color.White;
            this.btn412.Location = new System.Drawing.Point(225, 267);
            this.btn412.Name = "btn412";
            this.btn412.Size = new System.Drawing.Size(86, 60);
            this.btn412.TabIndex = 11;
            this.btn412.Text = "412";
            this.btn412.Click += new System.EventHandler(this.guna2Button12_Click);
            // 
            // btn411
            // 
            this.btn411.Animated = true;
            this.btn411.BorderRadius = 15;
            this.btn411.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn411.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn411.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn411.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn411.FillColor = System.Drawing.Color.DarkGreen;
            this.btn411.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btn411.ForeColor = System.Drawing.Color.White;
            this.btn411.Location = new System.Drawing.Point(121, 267);
            this.btn411.Name = "btn411";
            this.btn411.Size = new System.Drawing.Size(86, 60);
            this.btn411.TabIndex = 10;
            this.btn411.Text = "411";
            this.btn411.Click += new System.EventHandler(this.guna2Button11_Click);
            // 
            // btn410
            // 
            this.btn410.Animated = true;
            this.btn410.BorderRadius = 15;
            this.btn410.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn410.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn410.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn410.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn410.FillColor = System.Drawing.Color.DarkGreen;
            this.btn410.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btn410.ForeColor = System.Drawing.Color.White;
            this.btn410.Location = new System.Drawing.Point(16, 267);
            this.btn410.Name = "btn410";
            this.btn410.Size = new System.Drawing.Size(86, 60);
            this.btn410.TabIndex = 9;
            this.btn410.Text = "410";
            this.btn410.Click += new System.EventHandler(this.guna2Button10_Click);
            // 
            // btn309
            // 
            this.btn309.Animated = true;
            this.btn309.BorderRadius = 15;
            this.btn309.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn309.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn309.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn309.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn309.FillColor = System.Drawing.Color.DarkGreen;
            this.btn309.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btn309.ForeColor = System.Drawing.Color.White;
            this.btn309.Location = new System.Drawing.Point(225, 197);
            this.btn309.Name = "btn309";
            this.btn309.Size = new System.Drawing.Size(86, 60);
            this.btn309.TabIndex = 8;
            this.btn309.Text = "309";
            this.btn309.Click += new System.EventHandler(this.guna2Button9_Click);
            // 
            // btn308
            // 
            this.btn308.Animated = true;
            this.btn308.BorderRadius = 15;
            this.btn308.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn308.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn308.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn308.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn308.FillColor = System.Drawing.Color.DarkGreen;
            this.btn308.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btn308.ForeColor = System.Drawing.Color.White;
            this.btn308.Location = new System.Drawing.Point(121, 197);
            this.btn308.Name = "btn308";
            this.btn308.Size = new System.Drawing.Size(86, 60);
            this.btn308.TabIndex = 7;
            this.btn308.Text = "308";
            this.btn308.Click += new System.EventHandler(this.guna2Button8_Click);
            // 
            // btn307
            // 
            this.btn307.Animated = true;
            this.btn307.BorderRadius = 15;
            this.btn307.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn307.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn307.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn307.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn307.FillColor = System.Drawing.Color.DarkGreen;
            this.btn307.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btn307.ForeColor = System.Drawing.Color.White;
            this.btn307.Location = new System.Drawing.Point(16, 197);
            this.btn307.Name = "btn307";
            this.btn307.Size = new System.Drawing.Size(86, 60);
            this.btn307.TabIndex = 6;
            this.btn307.Text = "307";
            this.btn307.Click += new System.EventHandler(this.guna2Button7_Click);
            // 
            // btn206
            // 
            this.btn206.Animated = true;
            this.btn206.BorderRadius = 15;
            this.btn206.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn206.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn206.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn206.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn206.FillColor = System.Drawing.Color.DarkGreen;
            this.btn206.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btn206.ForeColor = System.Drawing.Color.White;
            this.btn206.Location = new System.Drawing.Point(225, 127);
            this.btn206.Name = "btn206";
            this.btn206.Size = new System.Drawing.Size(86, 60);
            this.btn206.TabIndex = 5;
            this.btn206.Text = "206";
            this.btn206.Click += new System.EventHandler(this.guna2Button6_Click);
            // 
            // btn205
            // 
            this.btn205.Animated = true;
            this.btn205.BorderRadius = 15;
            this.btn205.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn205.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn205.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn205.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn205.FillColor = System.Drawing.Color.DarkGreen;
            this.btn205.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btn205.ForeColor = System.Drawing.Color.White;
            this.btn205.Location = new System.Drawing.Point(121, 127);
            this.btn205.Name = "btn205";
            this.btn205.Size = new System.Drawing.Size(86, 60);
            this.btn205.TabIndex = 4;
            this.btn205.Text = "205";
            this.btn205.Click += new System.EventHandler(this.guna2Button5_Click);
            // 
            // btn204
            // 
            this.btn204.Animated = true;
            this.btn204.BorderRadius = 15;
            this.btn204.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn204.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn204.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn204.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn204.FillColor = System.Drawing.Color.DarkGreen;
            this.btn204.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btn204.ForeColor = System.Drawing.Color.White;
            this.btn204.Location = new System.Drawing.Point(16, 127);
            this.btn204.Name = "btn204";
            this.btn204.Size = new System.Drawing.Size(86, 60);
            this.btn204.TabIndex = 3;
            this.btn204.Text = "204";
            this.btn204.Click += new System.EventHandler(this.guna2Button4_Click);
            // 
            // btn103
            // 
            this.btn103.Animated = true;
            this.btn103.BorderRadius = 15;
            this.btn103.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn103.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn103.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn103.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn103.FillColor = System.Drawing.Color.DarkGreen;
            this.btn103.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btn103.ForeColor = System.Drawing.Color.White;
            this.btn103.Location = new System.Drawing.Point(225, 57);
            this.btn103.Name = "btn103";
            this.btn103.Size = new System.Drawing.Size(86, 60);
            this.btn103.TabIndex = 2;
            this.btn103.Text = "103";
            this.btn103.Click += new System.EventHandler(this.guna2Button3_Click);
            // 
            // btn102
            // 
            this.btn102.Animated = true;
            this.btn102.BorderRadius = 15;
            this.btn102.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn102.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn102.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn102.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn102.FillColor = System.Drawing.Color.DarkGreen;
            this.btn102.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btn102.ForeColor = System.Drawing.Color.White;
            this.btn102.Location = new System.Drawing.Point(121, 57);
            this.btn102.Name = "btn102";
            this.btn102.Size = new System.Drawing.Size(86, 60);
            this.btn102.TabIndex = 1;
            this.btn102.Text = "102";
            this.btn102.Click += new System.EventHandler(this.guna2Button2_Click);
            // 
            // btn101
            // 
            this.btn101.Animated = true;
            this.btn101.BorderRadius = 15;
            this.btn101.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn101.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn101.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn101.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn101.FillColor = System.Drawing.Color.DarkGreen;
            this.btn101.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btn101.ForeColor = System.Drawing.Color.White;
            this.btn101.Location = new System.Drawing.Point(16, 57);
            this.btn101.Name = "btn101";
            this.btn101.Size = new System.Drawing.Size(86, 60);
            this.btn101.TabIndex = 0;
            this.btn101.Text = "101";
            this.btn101.Click += new System.EventHandler(this.guna2Button1_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(78, 373);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(44, 20);
            this.label9.TabIndex = 18;
            this.label9.Text = "Ücret";
            // 
            // tbucret
            // 
            this.tbucret.BorderRadius = 13;
            this.tbucret.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tbucret.DefaultText = "";
            this.tbucret.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.tbucret.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.tbucret.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbucret.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbucret.Enabled = false;
            this.tbucret.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbucret.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.tbucret.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbucret.Location = new System.Drawing.Point(126, 373);
            this.tbucret.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tbucret.Name = "tbucret";
            this.tbucret.PasswordChar = '\0';
            this.tbucret.PlaceholderText = "";
            this.tbucret.SelectedText = "";
            this.tbucret.Size = new System.Drawing.Size(145, 26);
            this.tbucret.TabIndex = 19;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(305, 378);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(21, 20);
            this.label10.TabIndex = 20;
            this.label10.Text = "....";
            this.label10.Visible = false;
            // 
            // guna2GroupBox2
            // 
            this.guna2GroupBox2.Controls.Add(this.dtpdogum);
            this.guna2GroupBox2.Controls.Add(this.label1);
            this.guna2GroupBox2.Controls.Add(this.label10);
            this.guna2GroupBox2.Controls.Add(this.tbad);
            this.guna2GroupBox2.Controls.Add(this.tbucret);
            this.guna2GroupBox2.Controls.Add(this.tbsoyad);
            this.guna2GroupBox2.Controls.Add(this.label9);
            this.guna2GroupBox2.Controls.Add(this.tbtckimlik);
            this.guna2GroupBox2.Controls.Add(this.btnkaydet);
            this.guna2GroupBox2.Controls.Add(this.tbtelno);
            this.guna2GroupBox2.Controls.Add(this.dtpcıkıstarihi);
            this.guna2GroupBox2.Controls.Add(this.tbodano);
            this.guna2GroupBox2.Controls.Add(this.label8);
            this.guna2GroupBox2.Controls.Add(this.label2);
            this.guna2GroupBox2.Controls.Add(this.label7);
            this.guna2GroupBox2.Controls.Add(this.label3);
            this.guna2GroupBox2.Controls.Add(this.dtpgiristarihi);
            this.guna2GroupBox2.Controls.Add(this.label4);
            this.guna2GroupBox2.Controls.Add(this.label6);
            this.guna2GroupBox2.Controls.Add(this.label5);
            this.guna2GroupBox2.FillColor = System.Drawing.SystemColors.ActiveCaption;
            this.guna2GroupBox2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2GroupBox2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2GroupBox2.Location = new System.Drawing.Point(12, 53);
            this.guna2GroupBox2.Name = "guna2GroupBox2";
            this.guna2GroupBox2.Size = new System.Drawing.Size(384, 573);
            this.guna2GroupBox2.TabIndex = 21;
            this.guna2GroupBox2.Text = "Müşteri Ekle";
            this.guna2GroupBox2.Click += new System.EventHandler(this.guna2GroupBox2_Click);
            // 
            // dtpdogum
            // 
            this.dtpdogum.Checked = true;
            this.dtpdogum.FillColor = System.Drawing.Color.White;
            this.dtpdogum.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.dtpdogum.Format = System.Windows.Forms.DateTimePickerFormat.Long;
            this.dtpdogum.Location = new System.Drawing.Point(126, 177);
            this.dtpdogum.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.dtpdogum.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.dtpdogum.Name = "dtpdogum";
            this.dtpdogum.Size = new System.Drawing.Size(200, 31);
            this.dtpdogum.TabIndex = 21;
            this.dtpdogum.Value = new System.DateTime(2024, 1, 12, 22, 26, 0, 771);
            // 
            // guna2Button18
            // 
            this.guna2Button18.Animated = true;
            this.guna2Button18.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button18.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button18.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button18.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button18.FillColor = System.Drawing.Color.DarkSlateGray;
            this.guna2Button18.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button18.ForeColor = System.Drawing.Color.White;
            this.guna2Button18.Location = new System.Drawing.Point(913, 633);
            this.guna2Button18.Name = "guna2Button18";
            this.guna2Button18.Size = new System.Drawing.Size(180, 35);
            this.guna2Button18.TabIndex = 22;
            this.guna2Button18.Text = "Geri";
            this.guna2Button18.Click += new System.EventHandler(this.guna2Button18_Click);
            // 
            // guna2GroupBox3
            // 
            this.guna2GroupBox3.Controls.Add(this.guna2Button20);
            this.guna2GroupBox3.Controls.Add(this.guna2Button19);
            this.guna2GroupBox3.Controls.Add(this.label11);
            this.guna2GroupBox3.Controls.Add(this.tbmusteriid);
            this.guna2GroupBox3.FillColor = System.Drawing.SystemColors.ActiveCaption;
            this.guna2GroupBox3.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2GroupBox3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2GroupBox3.Location = new System.Drawing.Point(402, 53);
            this.guna2GroupBox3.Name = "guna2GroupBox3";
            this.guna2GroupBox3.Size = new System.Drawing.Size(341, 572);
            this.guna2GroupBox3.TabIndex = 17;
            this.guna2GroupBox3.Text = "Müşteri Sil";
            // 
            // guna2Button20
            // 
            this.guna2Button20.Animated = true;
            this.guna2Button20.AnimatedGIF = true;
            this.guna2Button20.BorderRadius = 15;
            this.guna2Button20.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button20.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button20.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button20.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button20.FillColor = System.Drawing.Color.DimGray;
            this.guna2Button20.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button20.ForeColor = System.Drawing.Color.White;
            this.guna2Button20.Location = new System.Drawing.Point(20, 110);
            this.guna2Button20.Name = "guna2Button20";
            this.guna2Button20.Size = new System.Drawing.Size(145, 58);
            this.guna2Button20.TabIndex = 18;
            this.guna2Button20.Text = "Müşteriyi Sil";
            this.guna2Button20.Click += new System.EventHandler(this.guna2Button20_Click);
            // 
            // guna2Button19
            // 
            this.guna2Button19.Animated = true;
            this.guna2Button19.AnimatedGIF = true;
            this.guna2Button19.BorderRadius = 15;
            this.guna2Button19.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button19.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button19.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button19.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button19.FillColor = System.Drawing.Color.DimGray;
            this.guna2Button19.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button19.ForeColor = System.Drawing.Color.White;
            this.guna2Button19.Location = new System.Drawing.Point(171, 110);
            this.guna2Button19.Name = "guna2Button19";
            this.guna2Button19.Size = new System.Drawing.Size(145, 58);
            this.guna2Button19.TabIndex = 17;
            this.guna2Button19.Text = "Müşteri Bilgisi Getir";
            this.guna2Button19.Click += new System.EventHandler(this.guna2Button19_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(16, 77);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(121, 20);
            this.label11.TabIndex = 8;
            this.label11.Text = "Müşteri İd Giriniz";
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // tbmusteriid
            // 
            this.tbmusteriid.BorderRadius = 13;
            this.tbmusteriid.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tbmusteriid.DefaultText = "";
            this.tbmusteriid.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.tbmusteriid.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.tbmusteriid.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbmusteriid.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tbmusteriid.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbmusteriid.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.tbmusteriid.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tbmusteriid.Location = new System.Drawing.Point(171, 77);
            this.tbmusteriid.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tbmusteriid.Name = "tbmusteriid";
            this.tbmusteriid.PasswordChar = '\0';
            this.tbmusteriid.PlaceholderText = "";
            this.tbmusteriid.SelectedText = "";
            this.tbmusteriid.Size = new System.Drawing.Size(145, 26);
            this.tbmusteriid.TabIndex = 7;
            this.tbmusteriid.TextChanged += new System.EventHandler(this.guna2TextBox1_TextChanged);
            // 
            // guna2BorderlessForm1
            // 
            this.guna2BorderlessForm1.ContainerControl = this;
            this.guna2BorderlessForm1.DockIndicatorTransparencyValue = 0.6D;
            this.guna2BorderlessForm1.TransparentWhileDrag = true;
            // 
            // guna2ControlBox1
            // 
            this.guna2ControlBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2ControlBox1.Animated = true;
            this.guna2ControlBox1.BorderRadius = 15;
            this.guna2ControlBox1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(139)))), ((int)(((byte)(152)))), ((int)(((byte)(166)))));
            this.guna2ControlBox1.IconColor = System.Drawing.Color.White;
            this.guna2ControlBox1.Location = new System.Drawing.Point(1070, 12);
            this.guna2ControlBox1.Name = "guna2ControlBox1";
            this.guna2ControlBox1.Size = new System.Drawing.Size(45, 29);
            this.guna2ControlBox1.TabIndex = 23;
            this.guna2ControlBox1.Click += new System.EventHandler(this.guna2ControlBox1_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(16, 482);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(109, 20);
            this.label12.TabIndex = 17;
            this.label12.Text = "Boş Oda Sayısı:";
            // 
            // lbbosoda
            // 
            this.lbbosoda.AutoSize = true;
            this.lbbosoda.Location = new System.Drawing.Point(128, 482);
            this.lbbosoda.Name = "lbbosoda";
            this.lbbosoda.Size = new System.Drawing.Size(15, 20);
            this.lbbosoda.TabIndex = 18;
            this.lbbosoda.Text = "..";
            // 
            // lbdoluoda
            // 
            this.lbdoluoda.AutoSize = true;
            this.lbdoluoda.Location = new System.Drawing.Point(139, 517);
            this.lbdoluoda.Name = "lbdoluoda";
            this.lbdoluoda.Size = new System.Drawing.Size(15, 20);
            this.lbdoluoda.TabIndex = 20;
            this.lbdoluoda.Text = "..";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(16, 517);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(117, 20);
            this.label14.TabIndex = 19;
            this.label14.Text = "Dolu Oda Sayısı:";
            // 
            // YeniMusteri
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1127, 678);
            this.Controls.Add(this.guna2ControlBox1);
            this.Controls.Add(this.gbodalar);
            this.Controls.Add(this.guna2GroupBox3);
            this.Controls.Add(this.guna2Button18);
            this.Controls.Add(this.guna2GroupBox2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "YeniMusteri";
            this.Text = "YeniMusteri";
            this.Load += new System.EventHandler(this.YeniMusteri_Load);
            this.gbodalar.ResumeLayout(false);
            this.gbodalar.PerformLayout();
            this.guna2GroupBox2.ResumeLayout(false);
            this.guna2GroupBox2.PerformLayout();
            this.guna2GroupBox3.ResumeLayout(false);
            this.guna2GroupBox3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2TextBox tbad;
        private Guna.UI2.WinForms.Guna2TextBox tbsoyad;
        private Guna.UI2.WinForms.Guna2TextBox tbtckimlik;
        private Guna.UI2.WinForms.Guna2TextBox tbtelno;
        private Guna.UI2.WinForms.Guna2TextBox tbodano;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private Guna.UI2.WinForms.Guna2DateTimePicker dtpgiristarihi;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private Guna.UI2.WinForms.Guna2DateTimePicker dtpcıkıstarihi;
        private Guna.UI2.WinForms.Guna2Button btnkaydet;
        private Guna.UI2.WinForms.Guna2GroupBox gbodalar;
        private Guna.UI2.WinForms.Guna2Button guna2Button17;
        private Guna.UI2.WinForms.Guna2Button guna2Button16;
        private Guna.UI2.WinForms.Guna2Button btn515;
        private Guna.UI2.WinForms.Guna2Button btn514;
        private Guna.UI2.WinForms.Guna2Button btn513;
        private Guna.UI2.WinForms.Guna2Button btn412;
        private Guna.UI2.WinForms.Guna2Button btn411;
        private Guna.UI2.WinForms.Guna2Button btn410;
        private Guna.UI2.WinForms.Guna2Button btn309;
        private Guna.UI2.WinForms.Guna2Button btn308;
        private Guna.UI2.WinForms.Guna2Button btn307;
        private Guna.UI2.WinForms.Guna2Button btn206;
        private Guna.UI2.WinForms.Guna2Button btn205;
        private Guna.UI2.WinForms.Guna2Button btn204;
        private Guna.UI2.WinForms.Guna2Button btn103;
        private Guna.UI2.WinForms.Guna2Button btn102;
        private Guna.UI2.WinForms.Guna2Button btn101;
        private System.Windows.Forms.Label label9;
        private Guna.UI2.WinForms.Guna2TextBox tbucret;
        private System.Windows.Forms.Label label10;
        private Guna.UI2.WinForms.Guna2GroupBox guna2GroupBox2;
        private Guna.UI2.WinForms.Guna2Button guna2Button18;
        private Guna.UI2.WinForms.Guna2DateTimePicker dtpdogum;
        private Guna.UI2.WinForms.Guna2GroupBox guna2GroupBox3;
        private Guna.UI2.WinForms.Guna2BorderlessForm guna2BorderlessForm1;
        private Guna.UI2.WinForms.Guna2ControlBox guna2ControlBox1;
        private System.Windows.Forms.Label label11;
        private Guna.UI2.WinForms.Guna2TextBox tbmusteriid;
        private Guna.UI2.WinForms.Guna2Button guna2Button20;
        private Guna.UI2.WinForms.Guna2Button guna2Button19;
        private System.Windows.Forms.Label lbbosoda;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label lbdoluoda;
        private System.Windows.Forms.Label label14;
    }
}