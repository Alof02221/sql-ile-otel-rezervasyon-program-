﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Data.Sql;
using System.Data.SqlClient;

namespace WindowsFormsApp9
{
    public partial class Ayarlar : Form
    {
        private string connectionString = "Server=localhost;Database=otelsistem;User Id=otelsistem;Password=1230789Asd!";
        public Ayarlar()
        {
            InitializeComponent();
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            try
            {
                string kadi = tbkadi.Text;
                string sifre = tbsifre.Text;
                connection.Open();
                string query = "INSERT INTO admin (kullaniciadi,sifre) " +
                               "VALUES (@kullaniciadi, @sifre)";
                    using (MySqlCommand command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@kullaniciadi", kadi);
                        command.Parameters.AddWithValue("@sifre", sifre);
                        

                        command.ExecuteNonQuery();
                    }
                    MessageBox.Show("Veritabanına ekleme başarılı!");
                }
            catch (Exception ex)
            {
                    MessageBox.Show("Hatta :" + ex.Message);
                
            }   
        }

        private void guna2ControlBox1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void guna2Button2_Click(object sender, EventArgs e)
        {
            try
            {
                using (MySqlConnection connection = new MySqlConnection(connectionString))
                {
                    connection.Open();

                    int silinecekId = Convert.ToInt32(tbkullaniciid.Text);

                    string query = "DELETE FROM admin WHERE id = @id";

                    using (MySqlCommand command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@id", silinecekId);

                        int affectedRows = command.ExecuteNonQuery();

                        if (affectedRows > 0)
                        {
                            MessageBox.Show("Müşteri başarıyla silindi.");
                        }
                        else
                        {
                            MessageBox.Show("Belirtilen ID'ye sahip bir müşteri bulunamadı.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
        }

        private void guna2CheckBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (sifreyigöster.Checked)
            {
                tbsifre.PasswordChar = '\0';
            }
            else
            {
                tbsifre.PasswordChar = '*';
            }
        }

        private void guna2Button3_Click(object sender, EventArgs e)
        {
            Anasayfa form1 = new Anasayfa();
            form1.Show();
            this.Hide();
            
        }

        private void Ayarlar_Load(object sender, EventArgs e)
        {
           
        }

        private void btnpersonelekle_Click(object sender, EventArgs e)
        {
            using (MySqlConnection connection = new MySqlConnection(connectionString))
                try
                {
                    string kadi = personelkadi.Text;
                    string sifre = personelsifre.Text;
                    connection.Open();
                    string query = "INSERT INTO personel (kullaniciadi,sifre) " +
                                   "VALUES (@kullaniciadi, @sifre)";
                    using (MySqlCommand command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@kullaniciadi", kadi);
                        command.Parameters.AddWithValue("@sifre", sifre);


                        command.ExecuteNonQuery();
                    }
                    MessageBox.Show("Veritabanına ekleme başarılı!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Hatta :" + ex.Message);

                }
        }

        private void guna2CheckBox1_CheckedChanged_1(object sender, EventArgs e)
        {
            if (gösterpersonel.Checked)
            {
                personelsifre.PasswordChar = '\0';
            }
            else
            {
                personelsifre.PasswordChar = '*';
            }
        }

        private void guna2Button4_Click(object sender, EventArgs e)
        {
            try
            {
                using (MySqlConnection connection = new MySqlConnection(connectionString))
                {
                    connection.Open();

                    int silinecekId = Convert.ToInt32(tbid.Text);

                    string query = "DELETE FROM personel WHERE id = @id";

                    using (MySqlCommand command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@id", silinecekId);

                        int affectedRows = command.ExecuteNonQuery();

                        if (affectedRows > 0)
                        {
                            MessageBox.Show("Müşteri başarıyla silindi.");
                        }
                        else
                        {
                            MessageBox.Show("Belirtilen ID'ye sahip bir müşteri bulunamadı.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
        }
    }
}
